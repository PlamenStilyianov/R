#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: row_apply.R
#     Description: Execute R code on each row
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Apply given R function to each row
ore.rowApply(IRIS_TABLE,
             function(dat) {
                 # Any R code goes here. Operates on one row of IRIS_TABLE at
                 # a time
                 cbind(dat, dat$Petal.Length)
             })
