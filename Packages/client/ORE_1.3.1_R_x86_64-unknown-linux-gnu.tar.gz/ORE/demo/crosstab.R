#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: crosstab.R
#     Description: Frequency cross tabulations
#     Also see freq.R
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Single column frequency table
ore.crosstab(~ Species, IRIS_TABLE)

# 2 x 2 frequency table
x = ore.crosstab(Petal.Length ~ Species, IRIS_TABLE)
x

# x can be post processed
x = x[, c("Petal.Length", "Species", "ORE$FREQ")]
x

# Use PETAL_LENGTH column for weighting instead of frequency count
x = ore.crosstab(~ Species * Petal.Length, IRIS_TABLE)
x = x[, c("Species", "ORE$FREQ")]
x

# Discretize PETAL_LENGTH to build 2 x 2 tables
IRIS_TABLE$PETALBINS = ifelse(IRIS_TABLE$Petal.Length < 2, 1, 2)

# 2 column table with weighting
ore.crosstab(Species ~ PETALBINS * Sepal.Length, IRIS_TABLE)

#
# Ordering rows within the cross table
# Compare result with the above where FREQ was not used
ore.crosstab(Species ~ PETALBINS | FREQ, IRIS_TABLE)

#
# Multiple 2 column tables
# The following produces 2 tables.
# One for Species ~ Sepal.Length, The second for PETALBINS ~ Sepal.Length
#
ore.crosstab(Species + PETALBINS ~ Sepal.Length, IRIS_TABLE)

#
# Multiple 2 column tables
# Use all consecutive columns using "-" operator
# Sepal.Length to Species includes columns 1, 2, 3, 4 and 5.
# So 5 tables will be produces
# Sepal.Length ~ PETALBINS, Sepal.Width ~ PETALBINS, Petal.Length ~ PETALBINS,
# Petal.Width ~ PETALBINS and Species ~ PETALBINS
#
names(IRIS_TABLE)
ore.crosstab(Sepal.Length - Species ~ PETALBINS, IRIS_TABLE)

#
# Produce one table for each unique value of one or more columns
# Let us start with a 1 column table first
# Notice that there are 9 unique values for Petal.Length for
# Species == "setosa", 19 unique values for Species == "versicolor" and
# 20 unique values for Species == "virginica"
#
length(unique (IRIS_TABLE[IRIS_TABLE$Species == "setosa",]$Petal.Length) )
length(unique (IRIS_TABLE[IRIS_TABLE$Species == "versicolor",]$Petal.Length) )
length(unique (IRIS_TABLE[IRIS_TABLE$Species == "virginica",]$Petal.Length) )

# Accordingly the following produces a 1 column table with
# 9 + 19 + 20 = 48 rows
ore.crosstab(~ Species / Petal.Length, IRIS_TABLE)

#
# Let us produce a 2 column table for each unique value of Petal.Length
# within each species
#
ore.crosstab(Species ~ PETALBINS / Petal.Length, IRIS_TABLE)

#
# Stratification
#
ore.crosstab(~ Species ^ Petal.Length, IRIS_TABLE)
