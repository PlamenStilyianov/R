#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_ai.R
#     Description: ORE Interface to Oracle Data Mining Attribute Importance
#
#
#

##
## R iris data set
##

IRIS <- ore.push(iris)

ore.odmAI(Species ~ ., IRIS)


##
## R mtcars data set
##

m <- mtcars
m$gear <- as.factor(m$gear)
m$cyl  <- as.factor(m$cyl)
m$vs   <- as.factor(m$vs)
m$ID   <- 1:nrow(m)
MTCARS <- ore.push(data.frame(name=rownames(m),m))

ore.odmAI(gear ~ .-ID, MTCARS)
ore.odmAI(mpg ~ .-ID, MTCARS)

# End of odm_ai.R
