#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: sql_like.R
#     Description: Demonstrates how R commands map to SQL operations
#     The setup of a table in the database is repeated in each script
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Select Sepal.Length, Species from the iris data frame
iris_projected = iris[, c("Sepal.Length", "Species")]
class(iris_projected)
names(iris_projected)

iris_projected = IRIS_TABLE[, c("Sepal.Length", "Species")]
class(iris_projected)
names(iris_projected)

# Treatment of NULLS
# Select Sepal.Length, Species from the iris data frame
# where Petal.Length < 1.5
iris_filtered = iris[iris$Petal.Length < 1.5, c("Sepal.Length", "Species")]
class(iris_filtered)
names(iris_filtered)
nrow(iris_filtered)

iris_filtered = IRIS_TABLE[IRIS_TABLE$Petal.Length < 1.5,
                           c("Sepal.Length", "Species")]
class(iris_filtered)
names(iris_filtered)
nrow(iris_filtered)

# Alternate syntax filtering
iris_filtered = subset(iris, Petal.Length < 1.5)
iris_filtered = subset(IRIS_TABLE, Petal.Length < 1.5)

# More conditions in filtering - AND and OR
# All rows with either species = setosa OR species = versicolor
# and Petal.Width < 2.0
# select * from IRIS_TABLE where species = "setosa" OR
# species = "versicolor" AND Petal.Width < 2.0
iris_filtered = iris[(iris$Species == "setosa" |
                     iris$Species == "versicolor") &
                     iris$Petal.Width < 2.0,]
nrow(iris_filtered)

iris_filtered = IRIS_TABLE[(IRIS_TABLE$Species == "setosa" |
                            IRIS_TABLE$Species == "versicolor") &
                           IRIS_TABLE$Petal.Width < 2.0,]
nrow(iris_filtered)

# Column functions in project list
# select log(Petal.Width) as log_petal_width from iris
iris$log_petal_width = log(iris$Petal.Width)
names(iris)
head(iris)

# Get rid of the new column
iris = subset(iris, select = -log_petal_width)
names(iris)

IRIS_TABLE$LOG_Petal.Width=log(IRIS_TABLE$Petal.Width)
names(IRIS_TABLE)
head(IRIS_TABLE)

# Join
# Let's do a self-join on iris by the Species column
nrow(head(iris))
x = merge(head(iris), head(iris), by = "Species")
class(x)
nrow(x)

nrow(head(IRIS_TABLE))
x = merge(head(IRIS_TABLE), head(IRIS_TABLE), by = "Species")
class(x)
nrow(x)

# Union
x = rbind(head(iris), head(iris))
class(x)
names(x)
nrow(x)

x = rbind(head(IRIS_TABLE), head(IRIS_TABLE))
class(x)
names(x)
nrow(x)
