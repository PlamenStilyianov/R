#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: summary.R
#     Description: Demonstrates summary functionality
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Basic R summary functionality
summary(iris)
summary(IRIS_TABLE)

# More sophisticated summarizations available only for ore.frames
# Default aggregation functions : count, min, max and mean
# Other aggregation functions supported:
#  nmiss,css,uss,cv,sum,sumwgt,range,stddev,stderr,var,t,kurt,skew,
#  p1,p5,p10,p25,p50,p75,p90,p95,p99,qrange, mode
#
# Get default summaries for Petal.Length, rollup(Species)
x = ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
                order = "-class")
class(x)
x

# Rollup(more than 1 column)
# Generate summary for more than 1 variable
x = ore.summary(IRIS_TABLE, class = "Species, Petal.Width",
                var = "Petal.Length, Sepal.Length")
ore.sort(x, by = c("Species", "Petal.Width"))

# Get just the stats you need.
# Just get max and min values and
# Rename max and min with meaningful/readable names
x = ore.summary(IRIS_TABLE, class = "Species, Petal.Width",
                var = "Petal.Length, Sepal.Length",
                stats = "max(Petal.Length)=MPL, max(Sepal.Length)=MSL")
names(x)
ore.sort(x, by = c("Species", "Petal.Width"))

# Restrict output to certain group-bys from the ROLLUP()
# Compare with and without ways
x = ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
                stats = "min", ways = "1,nway", order = "-class")
names(x)
x
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            stats = "min", order = "-class")

# If the column being summarized is a frequency then it is typical
# to multiply by count.
# This is implemented as weight
# Compare output with and withou weight below
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            order = "-class")
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            weight = "Sepal.Width", order = "-class")

# Sort output by various criteria
# One may also use ore.sort. See rank.R for examples
#
# Sort by freq column
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            order = "freq")$"_FREQ_"
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            order = "-freq")$"_FREQ_"

# Sort by level column
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            order = "level")$"_LEVEL_"
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            order = "-level")$"_LEVEL_"

# Sort by grouping column
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            order = "class")
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            order = "-class")

# More complex aggregations
# Stratification columns are specified to generate summaries
# one per strata value
length(unique(IRIS_TABLE$Sepal.Length))

# 35 tables are generated since Sepal.Length has 35 unique values
# Note the output is a list now
x = ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
                group.by = "Sepal.Length")
class(x)
length(x)
ore.sort(x[[10]], by = "Species", reverse = TRUE)

# Multiple stratification columns can be specified
x = ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
                group.by = "Sepal.Length, Sepal.Width")
class(x)
length(x)
ore.sort(x[[400]], by = "Species", reverse = TRUE)

# For each aggregate, print Petal.Length of that observation that has
# the maximum value for Petal.Width
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            maxid = "Petal.Width/Petal.Length=PWForRowWithMaxPL",
            order = "-class")

# For each aggregate, print Petal.Length of that observation that has
# the minimum value for Petal.Width
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            minid = "Petal.Width/Petal.Length=PWForRowWithMinPL",
            order = "-class")

# All supported statistics
ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
            stats = c("mean,min,max,cnt,n,nmiss,css,uss,cv,sum,sumwgt",
                      "range,stddev,stderr,var,t,kurt,skew",
                      "p1,p5,p10,p25,p50,p75,p90,p95,p99,qrange",
                      "mode"),
            order = "-class")
