#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: freqanalysis.R
#     Description: Frequency cross tabulations
#     Also see crosstab.R
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Cross Tab is the precursor to building a frequency table with
# appropriate statistics

# 2 x 2 frequency table
x = ore.crosstab(Petal.Length ~ Species, IRIS_TABLE)

# Simple chi-square statistics
ore.freq(x, "PCHISQR")

# Continuity Adjusted Chi Square statistics
ore.freq(x, "AJCHI")

# Likelihood Ratio Chi Squared Statistics
ore.freq(x, "LRCHI")

# Mantel-Haenszel Chi Squared Statistics
ore.freq(x, "MHCHI")

# Mantel-Haenszel Chi Squared Statistics
ore.freq(x, "MHCHI")

#
# MCNEM requires a 2 x 2 table.
# Discretize PETAL_LENGTH to build 2 x 2 tables
# Restrict Species to vericolor and setosa
#
IRIS_TABLE$PETALBINS = ifelse(IRIS_TABLE$Petal.Length < 2, 1, 2)
IRIS_TABLE$SPECIESBINS = ifelse(IRIS_TABLE$Species == "setosa", 1, 2)
x = ore.crosstab(PETALBINS ~ SPECIESBINS, IRIS_TABLE)

ore.freq(x, "MCNEM")

# Fisher's exact test also works on 2x2 tables only
ore.freq(x, "FISHER")

# Odds Ratio
ore.freq(x, "OR")

#
# KAPPA requires a square NxN crosstab
#
IRIS_TABLE$PETALBINS = ifelse(IRIS_TABLE$Petal.Length < 2, 1,
                       ifelse(IRIS_TABLE$Petal.Length < 4, 2,
                              3))
x = ore.crosstab(Species ~ PETALBINS, IRIS_TABLE)

ore.freq(x, "KAPPA")

#
# Weighted Kappa coefficient
#
ore.freq(x, "WTKAP")

# Phi
ore.freq(x, "PHI")

# Cramer's V
ore.freq(x, "CRAMV")

# Contingency coefficient
ore.freq(x, "CONTGY")

# Bowker's test for symmetry
ore.freq(x, "TSYMM")

# Nx2 crosstab is requied for Cochran Armitage Test for Trend
x = ore.crosstab(Petal.Length ~ SPECIESBINS, IRIS_TABLE)

ore.freq(x, "TREND")

# Gamma Test
ore.freq(x, "GAMMA")

# Lambda Asymmetric C|R
ore.freq(x, "LAMCR")

# Lambda Asymmetric R|C
ore.freq(x, "LAMRC")

# Lambda Symmetric
ore.freq(x, "LAMDAS")

# Kendall's Tau b requires an NxN crosstab
x = ore.crosstab(Species ~ PETALBINS, IRIS_TABLE)

ore.freq(x, "KENTB")

# Pearson's correlation
ore.freq(x, "PCORR")

# Spearman's correlation
ore.freq(x, "SCORR")

# Stuart's Tau C
ore.freq(x, "STUTC")

# Somers' D (C|R)
ore.freq(x, "SMDCR")

# Somers' D (R|C)
ore.freq(x, "SMDRC")

# Cochran's Q test
ore.freq(x, "COCHQ")
