#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: rank.R
#     Description: Ranking of observations based on attributes
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Basic ranking on a column ordering by the ranking column asc
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=RankingColumn")
class(x)
y = ore.sort(data = x, by = "RankingColumn")
class(y)
y

# In-place ranking
# Replace the column being ranked by its rank
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length")
y = ore.sort(data = x, by = c("Petal.Length"))
y

# Using more than one column to generate ranks
x = ore.rank(data = IRIS_TABLE, var = c("Petal.Length=RankingColumn1",
                                   "Sepal.Length=RankingColumn2"))
y = ore.sort(data = x, by = c("RankingColumn1", "RankingColumn2"))
y

# Handling of ties
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=RankingColumn",
             ties = "low")
y = ore.sort(data = x, by = "RankingColumn")
y
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=RankingColumn",
             ties = "high")
y = ore.sort(data = x, by = "RankingColumn")
y
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=RankingColumn",
             ties = "dense")
y = ore.sort(data = x, by = "RankingColumn")
y
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=RankingColumn",
             ties = "mean")
y = ore.sort(data = x, by = "RankingColumn")
y

# Rank in the reverse order, high to low
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=RankingColumn",
             desc = TRUE)
y = ore.sort(data = x, by = "Petal.Length")
y
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=RankingColumn",
             desc = FALSE)
y = ore.sort(data = x, by = "Petal.Length")
y

# First partition the data set and then assign ranks within EACH
# partition
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=RankingColumn",
             group.by = "Species")
y = ore.sort(data = x, by = c("Species", "RankingColumn"))
y

# Dynamic binning of all observations into "n" groups
# based on ranks. This accomplishes n-tiling
x = ore.rank(data = IRIS_TABLE,
             var = "Petal.Length=RankingColumn",
             groups = 5)
y = ore.sort(data = x, by = "RankingColumn")
y

# Do n-tiling within EACH species
x = ore.rank(data = IRIS_TABLE,
             var = "Petal.Length=RankingColumn",
             group.by = "Species",
             groups = 5)
y = ore.sort(data = x, by = "Species")
y

# Using scores
x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=ScoringColumn",
             group.by = "Species", score = "blom")
y = ore.sort(data = x, by = c("Species", "ScoringColumn"))
y

x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=ScoringColumn",
             group.by = "Species", score = "nplus1")
y = ore.sort(data = x, by = c("Species", "ScoringColumn"))
y

x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=ScoringColumn",
             group.by = "Species", score = "percent")
y = ore.sort(data = x, by = c("Species", "ScoringColumn"))
y

x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=ScoringColumn",
             group.by = "Species", score = "fraction")
y = ore.sort(data = x, by = c("Species", "ScoringColumn"))
y

x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=ScoringColumn",
             group.by = "Species", score = "savage")
y = ore.sort(data = x, by = c("Species", "ScoringColumn"))
y

x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=ScoringColumn",
             group.by = "Species", score = "tukey")
y = ore.sort(data = x, by = c("Species", "ScoringColumn"))
y

x = ore.rank(data = IRIS_TABLE, var = "Petal.Length=ScoringColumn",
             group.by = "Species", score = "vw")
y = ore.sort(data = x, by = c("Species", "ScoringColumn"))
y
