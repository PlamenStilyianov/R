#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: hypothesis.R
#     Description: Hypothesis Testing Functions
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Exact Binomial Test
# We need a variable in 2 categories.
# So bin PETAL_LENGTH into 2 categories first
IRIS_TABLE$PETALBINS = ifelse(IRIS_TABLE$Petal.Length < 2, 1, 2)
binom.test(IRIS_TABLE$PETALBINS)

# Chi Square Test
chisq.test(IRIS_TABLE$PETALBINS)

# One sample K-S Test for given probabilities
ks.test(IRIS_TABLE$Petal.Length, "pexp", rate = 4)
ks.test(IRIS_TABLE$Petal.Length, "pnorm", mean = 39, sd = 13.5)
ks.test(IRIS_TABLE$Petal.Length, "ppois", lambda = 4)
ks.test(IRIS_TABLE$Petal.Length, "punif", min = 59, max = 92)
ks.test(IRIS_TABLE$Petal.Length, "pweibull", shape = 3, scale = 44)

# Two sample K-S Test
ks.test(IRIS_TABLE$Petal.Length, IRIS_TABLE$Sepal.Length)

# T-test with different alternate hypothesis possibilities */
t.test(IRIS_TABLE$Petal.Length, alternative = "two.sided", mu = 0,
       conf.level = 0.9)
t.test(IRIS_TABLE$Petal.Length, alternative = "less", mu = 0,
       conf.level = 0.9)
t.test(IRIS_TABLE$Petal.Length, alternative = "greater", mu = 0,
       conf.level = 0.9)

# F test to compare variances
var.test(IRIS_TABLE$Petal.Length, IRIS_TABLE$Sepal.Length, ratio = 0.75,
         alternative = "two.sided", conf.level = 0.9)
var.test(IRIS_TABLE$Petal.Length, IRIS_TABLE$Sepal.Length, ratio = 0.75,
         alternative = "greater", conf.level = 0.9)
var.test(IRIS_TABLE$Petal.Length, IRIS_TABLE$Sepal.Length, ratio = 0.75,
         alternative = "less", conf.level = 0.9)

# Wilcoxon signed rank test
wilcox.test(IRIS_TABLE$Petal.Length - 3.8, alternative = "greater", mu = 0)
wilcox.test(IRIS_TABLE$Petal.Length - 1.8, alternative = "two.sided", mu = 0)
wilcox.test(IRIS_TABLE$Petal.Length - 2.8, alternative = "less", mu = 0)
