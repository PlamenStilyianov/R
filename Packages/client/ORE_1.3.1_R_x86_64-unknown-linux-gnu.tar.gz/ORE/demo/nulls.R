#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: nulls
#     Description: Demonstrates handling of nulls in SQL vs. NAs in R
#
#
#

## Set page width
options(width = 80)

# Push the built-in airquality data frame to the database
AIRQUALITY <- ore.push(airquality)

# Display the class of AIRQUALITY 
class(AIRQUALITY)

# Let us see what the behavior of R is with NAs
# Return all observations where ozone < 30
# Compare with explicit exclusion of NAs
nrow(airquality[airquality$Ozone < 30,])

# Explicit exclusion of NAs
nrow(airquality[airquality$Ozone < 30 & !is.na(airquality$Ozone),])

# Default behavior on SQL tables is excluding NULLS in output
nrow(AIRQUALITY[AIRQUALITY$Ozone < 30,])

# If you want R's NA behavior then request for it explicitly..
options(ore.na.extract = TRUE)
nrow(AIRQUALITY[AIRQUALITY$Ozone < 30,])
