#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_dt.R
#     Description: ORE Interface to Oracle Data Mining Decision Tree
#

##
## R mtcars data set
##

m <- mtcars
m$gear <- as.factor(m$gear)
m$cyl  <- as.factor(m$cyl)
m$vs   <- as.factor(m$vs)
m$ID   <- 1:nrow(m)
MTCARS <- ore.push(m)
row.names(MTCARS) <- MTCARS$ID

dt.mod  <- NULL
dt.mod  <- ore.odmDT(gear ~ ., MTCARS)
summary(dt.mod)
dt.res  <- predict (dt.mod, MTCARS,"gear")
with(dt.res, table(gear,PREDICTION))  # generate confusion matrix

dt.mod  <- NULL
dt.mod  <- ore.odmDT(gear ~ ., MTCARS, impurity.metric="entropy")
summary(dt.mod)
dt.res  <- predict (dt.mod, MTCARS,"gear")
with(dt.res, table(gear,PREDICTION))  # generate confusion matrix


# End of odm_dt.R
