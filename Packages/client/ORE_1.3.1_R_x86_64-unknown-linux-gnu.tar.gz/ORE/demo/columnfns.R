#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: columnfns.R
#     Description: Demonstrates use of column functions
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Select distinct(species) from iris_table
unique(IRIS_TABLE$Species)

# Select function(column) from iris_table
# where function is one of
# min, max, sd, mad, mean, fivenum, var, IQR, quantile, tabulate
# etc shown below
min(IRIS_TABLE$Petal.Length)
max(IRIS_TABLE$Petal.Length)
sd(IRIS_TABLE$Petal.Length)
mad(IRIS_TABLE$Petal.Length)
mean(IRIS_TABLE$Petal.Length)
fivenum(IRIS_TABLE$Petal.Length)
var(IRIS_TABLE$Petal.Length)
IQR(IRIS_TABLE$Petal.Length)
quantile(IRIS_TABLE$Petal.Length)
tabulate(IRIS_TABLE$Petal.Length)

log(IRIS_TABLE$Petal.Length)
log10(IRIS_TABLE$Petal.Length)
log2(IRIS_TABLE$Petal.Length)

abs(IRIS_TABLE$Petal.Length)
sqrt(IRIS_TABLE$Petal.Length)

exp(IRIS_TABLE$Petal.Length)
expm1(IRIS_TABLE$Petal.Length)
round(IRIS_TABLE$Petal.Length)

# Special functions
besselI(IRIS_TABLE$Petal.Length, nu = 0.5)
besselK(IRIS_TABLE$Petal.Length, nu = 0.5)
besselJ(IRIS_TABLE$Petal.Length, nu = 0.5)
besselY(IRIS_TABLE$Petal.Length, nu = 0.5)

gamma(IRIS_TABLE$Petal.Length)
lgamma(IRIS_TABLE$Petal.Length)
digamma(IRIS_TABLE$Petal.Length)
trigamma(IRIS_TABLE$Petal.Length)

# Frequency counts
# First bin PETAL_LENGTH for readability
IRIS_TABLE$PLBINS = ifelse(IRIS_TABLE$Petal.Length < 2, "SMALL",
                    ifelse(IRIS_TABLE$Petal.Length < 4, "MEDIUM",
                           "LARGE"))
table(IRIS_TABLE$Species, IRIS_TABLE$PLBINS)

# String Functions
substr(IRIS_TABLE$Species, 1, 2)
tolower(IRIS_TABLE$Species)
toupper(IRIS_TABLE$Species)
x = sub("s", "v", IRIS_TABLE$Species)
x = chartr("se", "xx", IRIS_TABLE$Species)
x
