#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: datastore.R
#     Description: ORE Interface to DataStore
#

##
## Save R object to datastore
##

# load three datasets to current workspace
data(iris)
data(mtcars)
data(quakes)

# move a dataset to a new environment
env = new.env()
assign("quakes", quakes, envir = env)
rm(quakes)

# save two datasets to a datastore
ore.save(iris, mtcars, name = "ds_rdata", 
         description = "R datasets")

# save a dataset from environment to an existing datastore
ore.save(quakes, name = "ds_rdata", envir = env, append = TRUE)

# save model to a datastore
mod_lm <- lm(hp ~ cyl + disp, mtcars)
mod_glm <- glm(hp ~ cyl + disp, mtcars, family = gaussian())
ore.save(list = c("mod_lm", "mod_glm"), name = "ds_rmodel")

rm(iris, mtcars, mod_lm, mod_glm)
ls()
rm(quakes, envir = env)
ls(envir = env)

##
## Show datastore and saved objects
##

# show all saved datastore ordered by datastore.name
res <- ore.datastore()
res[order(res$datastore.name),]

# show datastore whose names match pattern
res <- ore.datastore(pattern = "*rdata")
res[order(res$datastore.name),]

# show summary about one datastore ordered by object.name
res <- ore.datastoreSummary(name = "ds_rdata")
res[order(res$object.name),]
rm(res)

##
## load objects from datastore
##

# load all R objects from datastore to current workspace
ore.load(name = "ds_rdata")
ls()

# load the named R object from datastore to an environment
ore.load(name = "ds_rmodel", list = "mod_lm", envir = env)
ls(envir = env)

rm(mod_lm, envir = env)
rm(iris, mtcars, quakes, env)

##
## delete datastore
##

# delete named datastore
ore.delete(name = "ds_rdata")
ore.datastore()

# delete all datastores whose names match pattern
sapply(ore.datastore(pattern = "*_rmodel")$datastore.name, ore.delete)
ore.datastore()
ls()

# End of datastore.R
