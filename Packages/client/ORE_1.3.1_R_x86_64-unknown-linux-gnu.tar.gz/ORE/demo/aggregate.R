#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: aggregate.R
#     Description: Demonstrates aggregations
#     See also summary.R
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Select count(Petal.Length) group by species
x = aggregate(IRIS_TABLE$Petal.Length,
              by = list(species = IRIS_TABLE$Species),
              FUN = length)
class(x)
x

# Repeat FUN = summary, mean, min, max, sd, median, IQR
aggregate(IRIS_TABLE$Petal.Length, by = list(species = IRIS_TABLE$Species),
          FUN = summary)
aggregate(IRIS_TABLE$Petal.Length, by = list(species = IRIS_TABLE$Species),
          FUN = mean)
aggregate(IRIS_TABLE$Petal.Length, by = list(species = IRIS_TABLE$Species),
          FUN = min)
aggregate(IRIS_TABLE$Petal.Length, by = list(species = IRIS_TABLE$Species),
          FUN = max)
aggregate(IRIS_TABLE$Petal.Length, by = list(species = IRIS_TABLE$Species),
          FUN = sd)
aggregate(IRIS_TABLE$Petal.Length, by = list(species = IRIS_TABLE$Species),
          FUN = median)
aggregate(IRIS_TABLE$Petal.Length, by = list(species = IRIS_TABLE$Species),
          FUN = IQR)

# More than one grouping column
x = aggregate(IRIS_TABLE$Petal.Length,
              by = list(species = IRIS_TABLE$Species,
                        width = IRIS_TABLE$Petal.Width),
              FUN = length)
x

# Sort the result by ascending value of count
ore.sort(data = x, by = "x")

# by descending value
ore.sort(data = x, by = "x", reverse = TRUE)

# Preserve just 1 row for duplicate x's
ore.sort(data = x, by = "x", unique.keys = TRUE)
ore.sort(data = x, by = "x", unique.keys = TRUE, unique.data = TRUE)
