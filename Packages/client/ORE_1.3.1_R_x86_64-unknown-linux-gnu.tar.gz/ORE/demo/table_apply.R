#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: table_apply.R
#     Description: Execute R code on all rows of a table
#                  passed in at once
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE
class(IRIS_TABLE)

# Build a regression model using in memory data
mod = lm(Sepal.Length ~ . - Species, data = iris)

# Use tableApply to predict using the model on all rows of IRIS_TABLE
ore.tableApply(IRIS_TABLE,
               function(dat, mod)
               {
                   cbind(dat, PRED = predict(mod, newdata = dat))
               },
               mod = mod)
