#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: basic.R
#     Description: Demonstrates basic connectivity to database
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Basic commands

# Number of rows
nrow(iris)
nrow(IRIS_TABLE)

# Column names of the data frame
names(iris)
names(IRIS_TABLE)

# Number of columns of the data frame
length(iris)
length(IRIS_TABLE)

# Head
head(iris, n = 5)
head(IRIS_TABLE, n = 5)

# Vectors
class(iris$Sepal.Length)
class(IRIS_TABLE$Sepal.Length)

class(iris$Species)
class(IRIS_TABLE$Species)

# is variants
is.factor(iris$Species)
is.factor(IRIS_TABLE$Species)
is.ore.factor(IRIS_TABLE$Species)

# Number of characters in each column value
nchar(as.character(iris$Species))
nchar(as.character(IRIS_TABLE$Species))
