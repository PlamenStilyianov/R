#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_svm.R
#     Description: ORE Interface to Oracle Data Mining SVM
#

##
## R iris data set
##

IRIS <- ore.push(iris)

svm.mod  <- NULL
svm.res  <- NULL
svm.mod  <- ore.odmSVM(Species ~ ., IRIS,"classification")
summary(svm.mod)
coef(svm.mod)
svm.res  <- predict (svm.mod, IRIS,"Species")
with(svm.res, table(Species,PREDICTION))  # generate confusion matrix

##
## Synthetic data set
##

set.seed(7654)
x <- seq(0.1, 5, by = 0.02)
y <- log(x) + rnorm(x, sd = 0.2)

## ore.odmSVM
dat <-ore.push(data.frame(X=x, Y=y))
svm.mod1 <- NULL
svm.mod1 <- ore.odmSVM(Y~X,dat, "regression",kernel.function = "linear",auto.data.prep=FALSE)
svm.res1 <- predict(svm.mod1,dat,supplemental.cols=c("X","Y"))
plot(dat,main="OREdm ODM SVM - linear model")
points(x, log(x), col = 2)
points(svm.res1$X, svm.res1$PREDICTION, col = 4)

# ore.odmSVM with default settings
svm.mod2 <- NULL
svm.mod2 <- ore.odmSVM(Y~X,dat, "regression")
summary(svm.mod2)
svm.res2 <- predict(svm.mod2,dat,supplemental.cols="X")
plot(dat,main="Comparing SVM Model Results")
points(x, log(x), col = 2)                     
points(svm.res2$X, svm.res2$PREDICTION, col = 4)

# End of odm_svm.R
