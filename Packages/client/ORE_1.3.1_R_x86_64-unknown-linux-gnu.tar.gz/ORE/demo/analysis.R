#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: analysis.R
#     Description: Demonstrates basic analysis & data processing operations
#     The setup of a table in the database is repeated in each script
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Number of unique specifies
length(unique(iris$Species))
length(unique(IRIS_TABLE$Species))

# What are the unique species ?
levels(iris$Species)
levels(IRIS_TABLE$Species)

# Alternatively..
unique(iris$Species)
unique(IRIS_TABLE$Species)

# Count of observations with species = "setosa"
nrow(iris[iris$Species == "setosa", ])
nrow(IRIS_TABLE[IRIS_TABLE$Species == "setosa", ])

# Count of rows where species == "setosa" and Petal.Width=0.3
# Notice the use of a single & to represent a conjunction (AND)
nrow(iris[iris$Species == "setosa" & iris$Petal.Width == 0.3, ])
nrow(IRIS_TABLE[IRIS_TABLE$Species == "setosa" &
                IRIS_TABLE$Petal.Width == 0.3, ])

# Exclude observations with Petal.Width > 0.3
iris_new = iris[iris$Petal.Width <= 0.3, ]
nrow(iris_new)
class(iris_new)

# On an ore.frame the result is just a logical query
iris_new = IRIS_TABLE[IRIS_TABLE$Petal.Width <= 0.3, ]
nrow(iris_new)

# Look at the class of iris_new to confirm that it is indeed
# a logical query
class(iris_new)

# Missing is NA in R.
# Lets count observations where Petal.Length is missing
#

nrow(iris[is.na(iris$Petal.Length), ])
nrow(IRIS_TABLE[is.na(IRIS_TABLE$Petal.Length), ])

# Or the other way round..
nrow(iris[!is.na(iris$Petal.Length),])
nrow(IRIS_TABLE[!is.na(IRIS_TABLE$Petal.Length), ])
