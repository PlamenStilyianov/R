var chapters = [
  { topic: "chapter", section: "1", title: "Overview of Oracle R Enterprise", anchor: "", file: "intro.htm" },
  { topic: "chapter", section: "2", title: "Installation", anchor: "BABGGEEF", file: "install.htm" },
  { topic: "chapter", section: "3", title: "Using Oracle R Enterprise", anchor: "CEGCICBB", file: "using.htm" },
  { topic: "chapter", section: "4", title: "Oracle R Enterprise Statistical Functions", anchor: "CIHEIEBC", file: "procs.htm" },
  { topic: "appendix", section: "A", title: "Third-Party Licenses", anchor: "", file: "license.htm" },
  { } ];
