test_ore.vector_boxplot <- function()
{
    compareBPStats <- function(x, y)
    {
        x[["out"]] <- sort(x[["out"]])
        y[["out"]] <- sort(x[["out"]])
        checkEquals(x, y, tolerance = 5e-6)
    }

    for (j in c("ID", "AGE", "YRS_RESIDENCE"))
        compareBPStats(boxplot(NARROW[[j]], plot = FALSE),
                       boxplot(ore.pull(NARROW[[j]]), plot = FALSE))
}

test_list_boxplot <- function()
{
    compareBPStats <- function(x, y)
    {
        x[["out"]] <- sort(x[["out"]])
        y[["out"]] <- sort(x[["out"]])
        checkEquals(x, y, tolerance = 5e-6)
    }

    compareBPStats(boxplot(list(NARROW[["ID"]], NARROW[["AGE"]]),
                           plot = FALSE),
                   boxplot(list(ore.pull(NARROW[["ID"]]),
                                ore.pull(NARROW[["AGE"]])),
                           plot = FALSE))
}

